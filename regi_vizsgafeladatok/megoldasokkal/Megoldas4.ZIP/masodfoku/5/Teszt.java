public class Teszt{
	
public static void main(String args[]){
	
	String hibaszoveg = " Hib�s ind�t�s, h�rom val�s �rt�k kell! >java Teszt <a> <b> <c>";
	double a_ =0.,b_ =0., c_=0.;
	
	if(args.length !=3){
		System.err.println(hibaszoveg);
		System.exit(1);
	}
	
	try{
		a_ = Double.parseDouble(args[0]);
		b_ = Double.parseDouble(args[1]);
		c_ = Double.parseDouble(args[2]);
	}catch(NumberFormatException n){
		System.err.println(hibaszoveg);
		System.exit(1);
	}
	
		
	try{
		Elsofoku e1 = new Elsofoku(a_,b_);
		System.out.println("els�fok�:" + e1.getZerushely());
		e1.toFile();
	}catch (EgyutthatoException e){
		System.err.println(e);
	}
	
	
	try{
		Masodfoku m1 = new Masodfoku(a_,b_,c_);
		System.out.println("m�sodfok�:" + m1.getZerushely());
		m1.toFile();
	}catch (EgyutthatoException e){
		System.err.println(e);
	}
	
	
	
}	
	
}