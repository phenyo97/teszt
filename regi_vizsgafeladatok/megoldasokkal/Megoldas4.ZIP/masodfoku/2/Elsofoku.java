public class Elsofoku{
	
	protected double a, b;
		
	public Elsofoku(double a_, double b_){
		if (a_ == 0) {
			a = 1;
		}
		else{
			a = a_;
		}
		b = b_;
	}	
	
	public String getZerushely(){
		return "Az "+a+"*x+"+b+" egyenlet z�rushelye: x="+ (-b/a);
	}
}