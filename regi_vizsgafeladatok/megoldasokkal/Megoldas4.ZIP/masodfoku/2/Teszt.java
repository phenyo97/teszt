public class Teszt{
	
public static void main(String args[]){
	
	Elsofoku e1 = new Elsofoku(1,-2);
	Elsofoku e2 = new Elsofoku(1.5,2);
	
	Masodfoku m1 = new Masodfoku(1,-2,-2);
	Masodfoku m2 = new Masodfoku(2,0,-2);
	
	System.out.println("els�fok�:" + e1.getZerushely());
	System.out.println("els�fok�:" + e2.getZerushely());
	
	System.out.println("m�sodfok�:" + m1.getZerushely());
	System.out.println("m�sodfok�:" + m2.getZerushely());
	
	}	
	
}