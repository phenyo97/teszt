public class EgyutthatoException extends Exception{
	
	public String  toString(){
		return " Az egyenlet els� param�tere nem lehet z�rus!";	
	}
		
}