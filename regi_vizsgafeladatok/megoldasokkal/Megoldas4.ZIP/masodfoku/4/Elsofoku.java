import java.io.*;
public class Elsofoku{
	
	protected double a, b;
	
	public Elsofoku(double a_, double b_) throws EgyutthatoException {
		b = b_;
		a = a_;
		if (a_ == 0) {
			throw new EgyutthatoException();
		}
	}	
	
	
	public String getZerushely(){
		return "Az "+a+"*x+"+b+" egyenlet z�rushelye: x="+ (-b/a);
	}
	
	public void toFile(){
		try{
			PrintWriter out = new PrintWriter(new FileWriter("MEGOLDAS.TXT",true));
			out.println(getZerushely());
			out.close();
		}catch(IOException ie){
			System.err.println("Hiba a f�jlm�velet sor�n!");
		}
	}
}