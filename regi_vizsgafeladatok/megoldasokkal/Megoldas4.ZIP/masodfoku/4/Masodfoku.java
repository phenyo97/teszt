public class Masodfoku extends Elsofoku {
	
	private double c , diszkrnegyzete;
	private  String eredmeny;
	
	public Masodfoku(double a_, double b_, double c_)throws EgyutthatoException {
		super(a_,b_);
		c = c_;
		megoldokeplet();
	}	
	
	private int getdiszkrnegyzeteiminansDb(){
		diszkrnegyzete = b*b-4*a*c;
		if (diszkrnegyzete>0) {
			return 2;
		}
		else if (diszkrnegyzete==0) {
			return 1;
		}
		else{
			return 0;
		}
	}

	private void megoldokeplet(){
		double []x = new double[2];
		int db = getdiszkrnegyzeteiminansDb();
		
		switch(db){
			case 0:
			  eredmeny = "Nincs val�s megold�s!";
			break;	
			case 1:
			  x[0] = -b/(2*a); 
			  eredmeny = "x ="+ x[0];		
			break;
			case 2:
			  x[0] = (-b+Math.sqrt(diszkrnegyzete))/(2.0*a);
			  x[1] = (-b-Math.sqrt(diszkrnegyzete))/(2.0*a);
			  eredmeny =  "x1 ="+ x[0]+" x2 ="+x[1];	
		}
	}		
	
	public String getZerushely(){
		return "Az "+a+"*x^2+"+b+"*x+"+c+"=0 egyenlet megold�sa: "+eredmeny;
	}
	
	
}