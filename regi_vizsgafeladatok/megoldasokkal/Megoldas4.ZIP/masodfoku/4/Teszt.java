public class Teszt{
	
public static void main(String args[]){
	try{
		Elsofoku e1 = new Elsofoku(0,-2);
		System.out.println("els�fok�:" + e1.getZerushely());
		e1.toFile();
	}catch (EgyutthatoException e){
		System.err.println(e);
	}
	
	try{
		Elsofoku e2 = new Elsofoku(1.5,2);
		System.out.println("els�fok�:" + e2.getZerushely());
		e2.toFile();
	}catch (EgyutthatoException e){
		System.err.println(e);
	}
	
	
	try{
		Masodfoku m1 = new Masodfoku(1,-2,-2);
		System.out.println("m�sodfok�:" + m1.getZerushely());
		m1.toFile();
	}catch (EgyutthatoException e){
		System.err.println(e);
	}
	try{
		Masodfoku m2 = new Masodfoku(0,0,-2);
		System.out.println("m�sodfok�:" + m2.getZerushely());
		m2.toFile();
	}catch (EgyutthatoException e){
		System.err.println(e);
	}

	
}	
	
}