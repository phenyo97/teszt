public class Elsofoku{
	
	protected double a, b;
	
	public Elsofoku(double a_, double b_) throws EgyutthatoException {
		b = b_;
		a = a_;
		if (a_ == 0) {
			throw new EgyutthatoException();
		}
	}	
		
	public String getZerushely(){
		return "Az "+a+"*x+"+b+" egyenlet z�rushelye: x="+ (-b/a);
	}
}