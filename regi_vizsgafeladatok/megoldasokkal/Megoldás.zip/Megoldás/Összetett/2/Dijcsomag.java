import java.util.*;

public class Dijcsomag {
	private int szamlazasiEgyseg;
	private GregorianCalendar csucsidoEleje;
	private GregorianCalendar csucsidoVege;
	private int kedvezmenyesPercdij;
	private int csucsidoPercdij;
	
	public Dijcsomag(int sze, int kpd, int cspd) {
		szamlazasiEgyseg = sze;
		csucsidoEleje = new GregorianCalendar();
		csucsidoEleje.clear();
		csucsidoEleje.set(Calendar.HOUR_OF_DAY, 8);
		csucsidoVege = new GregorianCalendar();
		csucsidoVege.clear();
		csucsidoVege.set(Calendar.HOUR_OF_DAY, 16);
		kedvezmenyesPercdij = kpd;
		csucsidoPercdij =cspd;
	}
	
	public int tarifa(GregorianCalendar eleje, GregorianCalendar vege) {
		int hossz = (int)(vege.getTimeInMillis() - eleje.getTimeInMillis()) / 1000;
		int felhasznaltEgysegek = hossz / szamlazasiEgyseg;
		if(hossz % szamlazasiEgyseg != 0) {
			felhasznaltEgysegek++;
		}
		int percdij = (eleje.after(csucsidoEleje) && eleje.before(csucsidoVege)) ? csucsidoPercdij : kedvezmenyesPercdij;
		double egysegAra = percdij / 60. * szamlazasiEgyseg;
		return (int)(felhasznaltEgysegek * egysegAra);
	}
	
	public String toString() {
		return "Sz�ml�z�si egys�g:\t\t" + szamlazasiEgyseg + "mp.\n" +
			"Cs�csid� kezdete:\t\t" + String.format("%02d", csucsidoEleje.get(Calendar.HOUR_OF_DAY)) + ":" + String.format("%02d", csucsidoEleje.get(Calendar.MINUTE)) + "\n" +
			"Cs�csid� v�ge:\t\t\t" + String.format("%02d", csucsidoVege.get(Calendar.HOUR_OF_DAY)) + ":" + String.format("%02d", csucsidoVege.get(Calendar.MINUTE)) + "\n" +
			"A kedvezm�nyes percd�j:\t" + kedvezmenyesPercdij + "Ft\n" +
			"A cs�csid� percd�ja:\t\t" + csucsidoPercdij + "Ft";
	}
}