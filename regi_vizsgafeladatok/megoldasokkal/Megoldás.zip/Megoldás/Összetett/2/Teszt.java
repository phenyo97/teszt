import java.util.*;

public class Teszt {
	public static void main(String[] args) {
		Dijcsomag d1 = new Dijcsomag(1, 25, 40);
		System.out.println("Az els� d�jcsomag adatai:\n\n" + d1 + "\n");
		int d1eora = 9;
		int d1eperc = 17;
		int d1emp = 53;
		int d1vora = 9;
		int d1vperc = 18;
		int d1vmp = 36;
		GregorianCalendar d1eleje = new GregorianCalendar();
		d1eleje.clear();
		d1eleje.set(Calendar.HOUR_OF_DAY, d1eora);
		d1eleje.set(Calendar.MINUTE, d1eperc);
		d1eleje.set(Calendar.SECOND, d1emp);
		GregorianCalendar d1vege = new GregorianCalendar();
		d1vege.clear();
		d1vege.set(Calendar.HOUR_OF_DAY, d1vora);
		d1vege.set(Calendar.MINUTE, d1vperc);
		d1vege.set(Calendar.SECOND, d1vmp);
		System.out.println(d1eora + ":" + d1eperc + ":" + d1emp + " - " +
			d1vora + ":" + d1vperc + ":" + d1vmp + " k�lts�ge: " + d1.tarifa(d1eleje, d1vege) +
			"Ft.\n");
		
		Dijcsomag d2 = new Dijcsomag(30, 20, 30);
		System.out.println("A m�sodik d�jcsomag adatai:\n\n" + d2 + "\n");
		int d2eora = 9;
		int d2eperc = 17;
		int d2emp = 53;
		int d2vora = 9;
		int d2vperc = 18;
		int d2vmp = 22;
		GregorianCalendar d2eleje = new GregorianCalendar();
		d2eleje.clear();
		d2eleje.set(Calendar.HOUR_OF_DAY, d2eora);
		d2eleje.set(Calendar.MINUTE, d2eperc);
		d2eleje.set(Calendar.SECOND, d2emp);
		GregorianCalendar d2vege = new GregorianCalendar();
		d2vege.clear();
		d2vege.set(Calendar.HOUR_OF_DAY, d2vora);
		d2vege.set(Calendar.MINUTE, d2vperc);
		d2vege.set(Calendar.SECOND, d2vmp);
		System.out.println(d2eora + ":" + d2eperc + ":" + d2emp + " - " +
			d2vora + ":" + d2vperc + ":" + d2vmp + " k�lts�ge: " + d2.tarifa(d2eleje, d2vege) +
			"Ft.\n");
		
		Dijcsomag d3 = new Dijcsomag(60, 20, 30);
		System.out.println("A harmadik d�jcsomag adatai:\n\n" + d3 + "\n");
		int d3eora = 9;
		int d3eperc = 17;
		int d3emp = 53;
		int d3vora = 9;
		int d3vperc = 18;
		int d3vmp = 36;
		GregorianCalendar d3eleje = new GregorianCalendar();
		d3eleje.clear();
		d3eleje.set(Calendar.HOUR_OF_DAY, d3eora);
		d3eleje.set(Calendar.MINUTE, d3eperc);
		d3eleje.set(Calendar.SECOND, d3emp);
		GregorianCalendar d3vege = new GregorianCalendar();
		d3vege.clear();
		d3vege.set(Calendar.HOUR_OF_DAY, d3vora);
		d3vege.set(Calendar.MINUTE, d3vperc);
		d3vege.set(Calendar.SECOND, d3vmp);
		System.out.println(d3eora + ":" + d3eperc + ":" + d3emp + " - " +
			d3vora + ":" + d3vperc + ":" + d3vmp + " k�lts�ge: " + d3.tarifa(d3eleje, d3vege) +
			"Ft.\n");
	}
}