import java.util.*;
import java.io.*;

public class Dijcsomag {
	private static class Dijzona {
		private String nev;
		private GregorianCalendar eleje;
		private GregorianCalendar vege;
		private int percdij;
		
		public Dijzona(String n, GregorianCalendar e, GregorianCalendar v, int pd) {
			nev = n;
			eleje = e;
			vege = v;
			percdij = pd;
		}

		public String getNev() {
			return nev;
		}
		
		public GregorianCalendar getEleje() {
			return eleje;
		}
		
		public GregorianCalendar getVege() {
			return vege;
		}
		
		public int getPercdij() {
			return percdij;
		}

		public boolean isDijzonaban(GregorianCalendar mikor) {
			return (mikor.after(eleje) && mikor.before(vege)) ? true : false;
		}
	}
	
	private int szamlazasiEgyseg;
	private Vector<Dijzona> dijzonak;
	
	public Dijcsomag(int sze, int kpd, int cspd) {
		szamlazasiEgyseg = sze;
		dijzonak = new Vector<Dijzona>();
		GregorianCalendar eleje;
		GregorianCalendar vege;
		
		eleje = new GregorianCalendar();
		eleje.clear();
		vege = new GregorianCalendar();
		vege.clear();
		vege.set(Calendar.HOUR_OF_DAY, 8);
		vege.add(Calendar.MILLISECOND, -1);
		dijzonak.add(new Dijzona("Kedvezm�nyes1", eleje, vege, kpd));
		
		eleje = new GregorianCalendar();
		eleje.clear();
		eleje.set(Calendar.HOUR_OF_DAY, 8);
		vege = new GregorianCalendar();
		vege.clear();
		vege.set(Calendar.HOUR_OF_DAY, 16);
		dijzonak.add(new Dijzona("Cs�csid�", eleje, vege, cspd));
		
		eleje = new GregorianCalendar();
		eleje.clear();
		eleje.set(Calendar.HOUR_OF_DAY, 16);
		eleje.add(Calendar.MILLISECOND, 1);
		vege = new GregorianCalendar();
		vege.clear();
		vege.add(Calendar.DAY_OF_YEAR, 1);
		vege.add(Calendar.MILLISECOND, -1);
		dijzonak.add(new Dijzona("Kedvezm�nyes2", eleje, vege, kpd));
	}
	
	public int tarifa(GregorianCalendar eleje, GregorianCalendar vege) {
		int hossz = (int)(vege.getTimeInMillis() - eleje.getTimeInMillis()) / 1000;
		
		int felhasznaltEgysegek = hossz / szamlazasiEgyseg;
		if(hossz % szamlazasiEgyseg != 0) {
			felhasznaltEgysegek++;
		}
		
		Iterator<Dijzona> i = dijzonak.iterator();
		int percdij = -1;
		while(i.hasNext()) {
			Dijzona aktDZ = i.next();
			if(aktDZ.isDijzonaban(eleje)) {
				percdij = aktDZ.getPercdij();
				break;
			}
		}
		
		double egysegAra = percdij / 60. * szamlazasiEgyseg;
		
		return (int)(felhasznaltEgysegek * egysegAra);
	}
	
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Sz�ml�z�si egys�g:\t").append(szamlazasiEgyseg).append("mp.\n");
		Iterator<Dijzona> i = dijzonak.iterator();
		while(i.hasNext()) {
			Dijzona aktDZ = i.next();
			sb.append("D�jz�na kezdete:\t").append(String.format("%02d", aktDZ.getEleje().get(Calendar.HOUR_OF_DAY))).append(":").append(String.format("%02d", aktDZ.getEleje().get(Calendar.MINUTE))).append("\n");
			sb.append("D�jz�na v�ge:\t\t").append(String.format("%02d", aktDZ.getVege().get(Calendar.HOUR_OF_DAY))).append(":").append(String.format("%02d", aktDZ.getVege().get(Calendar.MINUTE))).append("\n");
			sb.append("Percd�j:\t\t\t").append(aktDZ.getPercdij()).append("Ft\n");
		}
		return sb.toString();
	}
	
	public void mentes(String fajl) {
		try {
			FileOutputStream fos = new FileOutputStream(fajl);
			DataOutputStream dos = new DataOutputStream(fos);
			dos.writeInt(szamlazasiEgyseg);
			dos.writeInt(dijzonak.get(0).getPercdij());
			dos.writeInt(dijzonak.get(1).getPercdij());
			dos.close();
			fos.close();
		} catch(FileNotFoundException fnfe) {
			System.err.println(fajl + " nem nyithat� meg �r�sra. " + fnfe);
		} catch(IOException ioe) {
			System.err.println("�r�si hiba l�pett fel a d�jcsomag adatainak �r�sa k�zben. " + ioe);
		}
	}

	public static Dijcsomag betoltes(String fajl) {
		Dijcsomag ujDijcsomag = null;
		try {
			FileInputStream fis = new FileInputStream(fajl);
			DataInputStream dis = new DataInputStream(fis);
			int sze = dis.readInt();
			int kpd = dis.readInt();
			int cspd = dis.readInt();
			dis.close();
			fis.close();
			ujDijcsomag = new Dijcsomag(sze, kpd, cspd);
		} catch(FileNotFoundException fnfe) {
			System.err.println(fajl + " nem nyithat� meg olvas�sra. " + fnfe);
		} catch(IOException ioe) {
			System.err.println("Olvas�si hiba l�pett fel a d�jcsomag adatainak olvas�sa k�zben. " + ioe);
		} finally {
			return ujDijcsomag;
		}
	}
}