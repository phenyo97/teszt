import java.util.*;
import java.io.*;

public class Teszt {
	private static int dijak(String dij) {
		try {
			int tarifa = Integer.parseInt(dij.trim());
			if(tarifa < 1 || tarifa > 200) {
				throw new Exception();
			}
			return tarifa;
		} catch(NumberFormatException nfe) {
			System.err.println("Hib�s sz�mform�tum! Adja meg �jra!");
			return -1;
		} catch(Exception e) {
			System.out.println("Az �rt�k az intervallumon k�v�l esik! Adjon meg m�sikat!");
			return -1;
		}
	}
	
	private static String beolvas() {
		byte[] bt = new byte[6];
		int hossz = 0;
		try {
			hossz = System.in.read(bt);
		} catch(IOException ioe) {}
		return new String(bt, 0, hossz);
	}
	
	public static void main(String[] args) {
		Dijcsomag d1 = null;
		Dijcsomag d2 = null;
		if(args.length != 0 && args.length != 2) {
			System.err.println("Hib�s param�terez�s! Ha pontosan k�t, [0;200] intervallumba es� eg�sz sz�mot ad meg, akkor ezek lesznek a d�jcsomagok tarif�i.");
			System.exit(1);
		} else if(args.length == 0) {
			d1 = new Dijcsomag(1, 25, 40);
			d2 = new Dijcsomag(60, 20, 30);
		} else {
			int t1 = dijak(args[0]);
			while(t1 == -1) {
				t1 = dijak(beolvas());
			}
			int t2 = dijak(args[1]);
			while(t2 == -1) {
				t2 = dijak(beolvas());
			}
			d1 = new Dijcsomag(1, t1, t2);
			d2 = new Dijcsomag(60, t1, t2);
		}

		System.out.println("Az els� d�jcsomag adatai:\n\n" + d1 + "\n");
		int d1eora = 9;
		int d1eperc = 17;
		int d1emp = 53;
		int d1vora = 9;
		int d1vperc = 18;
		int d1vmp = 36;
		GregorianCalendar d1eleje = new GregorianCalendar();
		d1eleje.clear();
		d1eleje.set(Calendar.HOUR_OF_DAY, d1eora);
		d1eleje.set(Calendar.MINUTE, d1eperc);
		d1eleje.set(Calendar.SECOND, d1emp);
		GregorianCalendar d1vege = new GregorianCalendar();
		d1vege.clear();
		d1vege.set(Calendar.HOUR_OF_DAY, d1vora);
		d1vege.set(Calendar.MINUTE, d1vperc);
		d1vege.set(Calendar.SECOND, d1vmp);
		System.out.println(d1eora + ":" + d1eperc + ":" + d1emp + " - " +
			d1vora + ":" + d1vperc + ":" + d1vmp + " k�lts�ge: " + d1.tarifa(d1eleje, d1vege) +
			"Ft.\n");
			
		System.out.println("A m�sodik d�jcsomag adatai:\n\n" + d2 + "\n");
		int d2eora = 9;
		int d2eperc = 17;
		int d2emp = 53;
		int d2vora = 9;
		int d2vperc = 18;
		int d2vmp = 36;
		GregorianCalendar d2eleje = new GregorianCalendar();
		d2eleje.clear();
		d2eleje.set(Calendar.HOUR_OF_DAY, d2eora);
		d2eleje.set(Calendar.MINUTE, d2eperc);
		d2eleje.set(Calendar.SECOND, d2emp);
		GregorianCalendar d2vege = new GregorianCalendar();
		d2vege.clear();
		d2vege.set(Calendar.HOUR_OF_DAY, d2vora);
		d2vege.set(Calendar.MINUTE, d2vperc);
		d2vege.set(Calendar.SECOND, d2vmp);
		System.out.println(d2eora + ":" + d2eperc + ":" + d2emp + " - " +
			d2vora + ":" + d2vperc + ":" + d2vmp + " k�lts�ge: " + d2.tarifa(d2eleje, d2vege) +
			"Ft.\n");

		d1.mentes("d1");
		Dijcsomag d3 = Dijcsomag.betoltes("d1");
		System.out.println("A harmadik (els�) d�jcsomag adatai:\n\n" + d3 + "\n");

		d2.mentes("d2");
		Dijcsomag d4 = Dijcsomag.betoltes("d2");
		System.out.println("A negyedik (m�sodik) d�jcsomag adatai:\n\n" + d4 + "\n");
	}
}