public class Dijcsomag {
	private int szamlazasiEgyseg;
	private int cse, csv;
	private int kedvezmenyesPercdij;
	private int csucsidoPercdij;
	
	public Dijcsomag(int sze, int kpd, int cspd) {
		szamlazasiEgyseg = sze;
		kedvezmenyesPercdij = kpd;
		csucsidoPercdij =cspd;
		cse = 8*60*60;
		csv = 16*60*60;
	}
	
	public int tarifa(int eo, int ep, int emp, int vo, int vp, int vmp) {
		int eleje = eo*60*60 + ep*60 + emp;
		int vege = vo*60*60 + vp*60 + vmp;
		int hossz = vege - eleje;
		int felhasznaltEgysegek = hossz / szamlazasiEgyseg;
		if(hossz % szamlazasiEgyseg != 0) {
			felhasznaltEgysegek++;
		}
		int percdij = (eleje>=cse && eleje<=csv) ? csucsidoPercdij : kedvezmenyesPercdij;
		double egysegAra = percdij / 60. * szamlazasiEgyseg;
		return (int)(felhasznaltEgysegek * egysegAra);
	}
	
	private int getOra(int mikor) {
		return mikor/3600;
	}
	
	private int getPerc(int mikor) {
		return (mikor%3600) / 60;
	}
	
	public String toString() {
		return "Sz�ml�z�si egys�g:\t\t" + szamlazasiEgyseg + "mp.\n" +
			"Cs�csid� kezdete:\t\t" + String.format("%02d", getOra(cse)) + ":" + String.format("%02d", getPerc(cse)) + "\n" +
			"Cs�csid� v�ge:\t\t\t" + String.format("%02d", getOra(csv)) + ":" + String.format("%02d", getPerc(csv)) + "\n" +
			"A kedvezm�nyes percd�j:\t" + kedvezmenyesPercdij + "Ft\n" +
			"A cs�csid� percd�ja:\t\t" + csucsidoPercdij + "Ft";
	}
}