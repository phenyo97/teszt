public class Teszt {
	public static void main(String[] args) {
		Dijcsomag d1 = new Dijcsomag(1, 25, 40);
		System.out.println("Az els� d�jcsomag adatai:\n\n" + d1 + "\n");
		int deora = 9;
		int deperc = 17;
		int demp = 53;
		int dvora = 9;
		int dvperc = 18;
		int dvmp = 36;
		System.out.println(deora + ":" + deperc + ":" + demp + " - " +
			dvora + ":" + dvperc + ":" + dvmp + " k�lts�ge: " + d1.tarifa(deora, deperc, demp, dvora, dvperc, dvmp) +
			"Ft.\n");
		
		Dijcsomag d2 = new Dijcsomag(60, 20, 30);
		System.out.println("A m�sodik d�jcsomag adatai:\n\n" + d2 + "\n");
		deora = 9;
		deperc = 17;
		demp = 53;
		dvora = 9;
		dvperc = 18;
		dvmp = 36;
		System.out.println(deora + ":" + deperc + ":" + demp + " - " +
			dvora + ":" + dvperc + ":" + dvmp + " k�lts�ge: " + d2.tarifa(deora, deperc, demp, dvora, dvperc, dvmp) +
			"Ft.\n");
			
		d1.mentes("d1");
		Dijcsomag d3 = Dijcsomag.betoltes("d1");
		System.out.println("A harmadik (azaz els�) d�jcsomag adatai:\n\n" + d3 + "\n");
		
		d2.mentes("d2");
		Dijcsomag d4 = Dijcsomag.betoltes("d2");
		System.out.println("A negyedik (azaz m�sodik) d�jcsomag adatai:\n\n" + d4 + "\n");
	}
}