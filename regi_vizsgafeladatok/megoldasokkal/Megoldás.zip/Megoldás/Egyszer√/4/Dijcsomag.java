import java.io.*;

public class Dijcsomag {
	private static class Dijzona {
		private String nev;
		private int eleje;
		private int vege;
		private int percdij;
		
		public Dijzona(String n, int e, int v, int pd) {
			nev = n;
			eleje = e;
			vege = v;
			percdij = pd;
		}

		public String getNev() {
			return nev;
		}
		
		public int getEleje() {
			return eleje;
		}
		
		public int getVege() {
			return vege;
		}
		
		public int getPercdij() {
			return percdij;
		}

		public boolean isDijzonaban(int mikor) {
			return (mikor>=eleje && mikor<=vege) ? true : false;
		}
	}

	private int szamlazasiEgyseg;
	private Dijzona[] dijzonak;
	public static final int KEDVEZMENYES = 0;
	public static final int CSUCSIDO = 1;
	
	public Dijcsomag(int sze, int kpd, int cspd) {
		szamlazasiEgyseg = sze;
		dijzonak = new Dijzona[2];
		dijzonak[KEDVEZMENYES] = new Dijzona("Kedvezm�nyes", 0, 0, kpd);
		dijzonak[CSUCSIDO] = new Dijzona("Cs�csid�", 8*60*60, 16*60*60, cspd);
	}
	
	public int tarifa(int eo, int ep, int emp, int vo, int vp, int vmp) {
		int eleje = eo*60*60 + ep*60 + emp;
		int vege = vo*60*60 + vp*60 + vmp;
		int hossz = vege - eleje;
		int felhasznaltEgysegek = hossz / szamlazasiEgyseg;
		if(hossz % szamlazasiEgyseg != 0) {
			felhasznaltEgysegek++;
		}
		int percdij = (dijzonak[CSUCSIDO].isDijzonaban(eleje)) ? dijzonak[CSUCSIDO].getPercdij() : dijzonak[KEDVEZMENYES].getPercdij();
		double egysegAra = percdij / 60. * szamlazasiEgyseg;
		return (int)(felhasznaltEgysegek * egysegAra);
	}
	
	private int getOra(int mikor) {
		return mikor/3600;
	}
	
	private int getPerc(int mikor) {
		return (mikor%3600) / 60;
	}
	
	public String toString() {
		return "Sz�ml�z�si egys�g:\t\t" + szamlazasiEgyseg + "mp.\n" +
			"Cs�csid� kezdete:\t\t" + String.format("%02d", getOra(dijzonak[CSUCSIDO].getEleje())) + ":" + String.format("%02d", getPerc(dijzonak[CSUCSIDO].getEleje())) + "\n" +
			"Cs�csid� v�ge:\t\t\t" + String.format("%02d", getOra(dijzonak[CSUCSIDO].getVege())) + ":" + String.format("%02d", getPerc(dijzonak[CSUCSIDO].getVege())) + "\n" +
			"A kedvezm�nyes percd�j:\t" + dijzonak[KEDVEZMENYES].getPercdij() + "Ft\n" +
			"A cs�csid� percd�ja:\t\t" + dijzonak[CSUCSIDO].getPercdij() + "Ft";
	}
	
	public void mentes(String fajl) {
		try {
			FileOutputStream fos = new FileOutputStream(fajl);
			DataOutputStream dos = new DataOutputStream(fos);
			dos.writeInt(szamlazasiEgyseg);
			dos.writeInt(dijzonak[KEDVEZMENYES].getPercdij());
			dos.writeInt(dijzonak[CSUCSIDO].getPercdij());
			dos.close();
			fos.close();
		} catch(FileNotFoundException fnfe) {
			System.err.println(fajl + " nem nyithat� meg �r�sra. " + fnfe);
		} catch(IOException ioe) {
			System.err.println("�r�si hiba l�pett fel a d�jcsomag adatainak �r�sa k�zben. " + ioe);
		}
	}
	
	public static Dijcsomag betoltes(String fajl) {
		Dijcsomag ujDijcsomag = null;
		try {
			FileInputStream fis = new FileInputStream(fajl);
			DataInputStream dis = new DataInputStream(fis);
			int sze = dis.readInt();
			int kpd = dis.readInt();
			int cspd = dis.readInt();
			dis.close();
			fis.close();
			ujDijcsomag = new Dijcsomag(sze, kpd, cspd);
		} catch(FileNotFoundException fnfe) {
			System.err.println(fajl + " nem nyithat� meg olvas�sra. " + fnfe);
		} catch(IOException ioe) {
			System.err.println("Olvas�si hiba l�pett fel a d�jcsomag adatainak olvas�sa k�zben. " + ioe);
		} finally {
			return ujDijcsomag;
		}
	}
}