import java.io.*;

public class Teszt {
	private static int dijak(String dij) {
		try {
			int tarifa = Integer.parseInt(dij.trim());
			if(tarifa < 1 || tarifa > 200) {
				throw new Exception();
			}
			return tarifa;
		} catch(NumberFormatException nfe) {
			System.err.println("Hib�s sz�mform�tum! Adja meg �jra!");
			return -1;
		} catch(Exception e) {
			System.out.println("Az �rt�k az intervallumon k�v�l esik! Adjon meg m�sikat!");
			return -1;
		}
	}
	
	private static String beolvas() {
		byte[] bt = new byte[6];
		int hossz = 0;
		try {
			hossz = System.in.read(bt);
		} catch(IOException ioe) {}
		return new String(bt, 0, hossz);
	}

	public static void main(String[] args) {
		Dijcsomag d1 = null;
		Dijcsomag d2 = null;
		if(args.length != 0 && args.length != 2) {
			System.err.println("Hib�s param�terez�s! Ha pontosan k�t, [0;200] intervallumba es� eg�sz sz�mot ad meg, akkor ezek lesznek a d�jcsomagok tarif�i.");
			System.exit(1);
		} else if(args.length == 0) {
			d1 = new Dijcsomag(1, 25, 40);
			d2 = new Dijcsomag(60, 20, 30);
		} else {
			int t1 = dijak(args[0]);
			while(t1 == -1) {
				t1 = dijak(beolvas());
			}
			int t2 = dijak(args[1]);
			while(t2 == -1) {
				t2 = dijak(beolvas());
			}
			d1 = new Dijcsomag(1, t1, t2);
			d2 = new Dijcsomag(60, t1, t2);
		}

		System.out.println("Az els� d�jcsomag adatai:\n\n" + d1 + "\n");
		int deora = 9;
		int deperc = 17;
		int demp = 53;
		int dvora = 9;
		int dvperc = 18;
		int dvmp = 36;
		System.out.println(deora + ":" + deperc + ":" + demp + " - " +
			dvora + ":" + dvperc + ":" + dvmp + " k�lts�ge: " + d1.tarifa(deora, deperc, demp, dvora, dvperc, dvmp) +
			"Ft.\n");
		
		System.out.println("A m�sodik d�jcsomag adatai:\n\n" + d2 + "\n");
		deora = 9;
		deperc = 17;
		demp = 53;
		dvora = 9;
		dvperc = 18;
		dvmp = 36;
		System.out.println(deora + ":" + deperc + ":" + demp + " - " +
			dvora + ":" + dvperc + ":" + dvmp + " k�lts�ge: " + d2.tarifa(deora, deperc, demp, dvora, dvperc, dvmp) +
			"Ft.\n");
			
		d1.mentes("d1");
		Dijcsomag d3 = Dijcsomag.betoltes("d1");
		System.out.println("A harmadik (azaz els�) d�jcsomag adatai:\n\n" + d3 + "\n");
		
		d2.mentes("d2");
		Dijcsomag d4 = Dijcsomag.betoltes("d2");
		System.out.println("A negyedik (azaz m�sodik) d�jcsomag adatai:\n\n" + d4 + "\n");
	}
}