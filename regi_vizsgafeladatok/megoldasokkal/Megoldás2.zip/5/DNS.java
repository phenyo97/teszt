import java.util.*;
import java.io.*;

public class DNS {
	private Map<String, Set<String>> cimek;
	
	public DNS() {
		cimek = new HashMap<String, Set<String>>();
	}
	
	// Uj IP cim - domainnev par bejegyzese
	public void addRecord(String IP, String name) throws IPFormatException {
		if(isFormatOK(IP)) {
			Set<String> domains;
			if(cimek.containsKey(IP)) {
				domains = cimek.get(IP);
			} else {
				domains = new HashSet<String>();
			}
			domains.add(name);
			cimek.put(IP, domains);
		} else {
			throw new IPFormatException("Az IP cim (" + IP + ") formatuma nem megfelelo.");
		}
	}
	
	// Adott IP cimhez bejegyzett domainnev lekerdezese
	public String getName(String IP) {
		return (String)cimek.get(IP).iterator().next();
	}
	
	// Valamennyi nyilvantartott adat visszaadasa
	public String toString() {
		return cimek.toString();
	}
	
	// Formai ellenorzes
	private boolean isFormatOK(String IP) {
		StringTokenizer st = new StringTokenizer(IP, ".");
		if(st.countTokens() != 4) return false;
		while(st.hasMoreTokens()) {
			try {
				int i = Integer.parseInt(st.nextToken());
				if(i<0 || i>255) return false;
			} catch(NumberFormatException nfe) {
				return false;
			}
		}
		return true;
	}
	
	// Nevhez tartozo IP cim 32 bites szamkent vissza
	public long getIP(String name) {
		Iterator<String> it = cimek.keySet().iterator();
		while(it.hasNext()) {
			String IP = it.next();
			Iterator<String> dit = cimek.get(IP).iterator();
			while(dit.hasNext()) {
				String domain = dit.next();
				if(name.equals(domain)) {
					long cim = 0l;
					StringTokenizer st = new StringTokenizer(IP, ".");
					while(st.hasMoreTokens()) {
						try {
							long l = Long.parseLong(st.nextToken());
							cim <<= 8;
							cim |= l;
						} catch(NumberFormatException nfe) {
							return -2l;
						}
					}
					return cim;
				}
			}
		}
		return -1l;
	}
	
	// Fajl betoltese
	public void read(String filename) {
		try {
			BufferedReader br = new BufferedReader(new FileReader(filename));
			String sor;
			while((sor = br.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(sor, ";");
				addRecord(st.nextToken(), st.nextToken());
			}
			br.close();
		} catch(Exception e) {
			System.err.println(e);
		}
	}
}