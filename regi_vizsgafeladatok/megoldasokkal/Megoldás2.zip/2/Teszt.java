public class Teszt {
	public static void main(String args[]) {
		DNS dns = new DNS();
		try {
			dns.addRecord("192.168.1.1", "utvalaszto.hu");
			dns.addRecord("192.168.1.1", "utvalaszto_ketto.hu");
			dns.addRecord("127.0.0.1", "sajatgep.com");
			dns.addRecord("193.224.128.1", "uni.sze.hu");
			
			// dns.addRecord("1.2.3.4.5", "hiba");
			// dns.addRecord("999.999.999.999", "hiba");
			// dns.addRecord("-1.-1.-1.-1", "hiba");
			// dns.addRecord("aaa.bbb.ccc.ddd", "hiba");
			dns.addRecord("1,2,3,4", "hiba");
		} catch(IPFormatException ife) {
			System.err.println(ife);
		}
			
		System.out.println("Sajat routerem neve: " + dns.getName("192.168.1.1"));
		System.out.println("Sajat gepem neve: " + dns.getName("127.0.0.1"));
		System.out.println("Egyetemi szerver neve: " + dns.getName("193.224.128.1"));
		
		System.out.println(dns);
	}
}