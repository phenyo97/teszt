import java.util.*;

public class DNS {
	private Map<String, String> cimek;
	
	public DNS() {
		cimek = new HashMap<String, String>();
	}
	
	// Uj IP cim - domainnev par bejegyzese
	public void addRecord(String IP, String name) throws IPFormatException {
		if(isFormatOK(IP)) {
			cimek.put(IP, name);
		} else {
			throw new IPFormatException("Az IP cim (" + IP + ") formatuma nem megfelelo.");
		}
	}
	
	// Adott IP cimhez bejegyzett domainnev lekerdezese
	public String getName(String IP) {
		return cimek.get(IP);
	}
	
	// Valamennyi nyilvantartott adat visszaadasa
	public String toString() {
		return cimek.toString();
	}
	
	// Formai ellenorzes
	private boolean isFormatOK(String IP) {
		StringTokenizer st = new StringTokenizer(IP, ".");
		if(st.countTokens() != 4) return false;
		while(st.hasMoreTokens()) {
			try {
				int i = Integer.parseInt(st.nextToken());
				if(i<0 || i>255) return false;
			} catch(NumberFormatException nfe) {
				return false;
			}
		}
		return true;
	}
}