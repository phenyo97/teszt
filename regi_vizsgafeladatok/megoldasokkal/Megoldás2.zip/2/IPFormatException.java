public class IPFormatException extends Exception {
	public IPFormatException(String message) {
		super(message);
	}
}