import java.io.*;

public class Teszt {
	public static void main(String args[]) {
		Haz h1 = new Haz(100, Ingatlan.GarazsTipus.SAJAT, 1000);
		Haz h2 = new Haz(150, Ingatlan.GarazsTipus.SAJAT, 1500);
		Lakas l1 = new Lakas(40, Ingatlan.GarazsTipus.NINCS, 3500);
		Lakas l2 = new Lakas(40, Ingatlan.GarazsTipus.TEREM, 4000);
		
		try {
			h1.addRezsi("V�z", 1800);
			h1.addRezsi("V�z", 1900);
			h2.addRezsi("Villany", 2800);
			l1.addRezsi("G�z", 5000);
			l2.addRezsi("Telefon", 3000);
		} catch(LetezoRezsiException lre) {
			System.err.println(lre);
		}
		
		System.out.println("h1 adatai: " + h1);
		System.out.println("h2 adatai: " + h2);
		System.out.println("l1 adatai: " + l1);
		System.out.println("l2 adatai: " + l2);
		System.out.println("l2 �tlagos havi rezsik�lts�ge: " + l2.getAtlRezsi());
			
		try {
			PrintWriter pw = new PrintWriter("ingatlanok.txt");
			h1.toFile(pw);
			h2.toFile(pw);
			l1.toFile(pw);
			l2.toFile(pw);
			pw.close();
		} catch(FileNotFoundException fnfe) {
			System.err.println("Hiba: " + fnfe);
		}
	}
}