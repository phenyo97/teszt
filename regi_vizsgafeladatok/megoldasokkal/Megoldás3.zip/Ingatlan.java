/* javadoc -d doksi -private *.java */

import java.util.*;
import java.io.*;

/**
A Haz �s Lakas oszt�lyok k�z�s ose. Minden Ingatlan-t jellemeznek a k�vetkezok:
<ul><li>alapter�let
<li>gar�zs
<li>rezsik�lts�gek.</ul>
*/
public abstract class Ingatlan {
	/** Felsorolt t�pus a gar�zs fajt�j�nak meghat�roz�s�hoz. */
	public static enum GarazsTipus {NINCS, SAJAT, TEREM};
	
	/** Az ingatlan alapter�lete m2-ben. */
	protected double alapterulet;
	/** A gar�zs t�pusa. */
	protected GarazsTipus garazs;
	/** A rezsik�lts�gek lek�pez�se. */
	protected Map<String, Integer> rezsikoltsegek;
	
	/** A konstruktornak az alapter�letet �s a gar�zs t�pus�t kell megadni. A t�pust a GarazsTipus 
	felsorolt t�pus valamelyik lehets�ges �rt�k�vel kell megadni. 
	@param at Az ingatlan alapter�lete, m2-ben.
	@param g A gar�zs t�pusa, amit a felsorolt t�pus seg�ts�g�vel kell meghat�rozni. */
	public Ingatlan(double at, GarazsTipus g) {
		alapterulet = at;
		garazs = g;
		rezsikoltsegek = new TreeMap<String, Integer>();
	}
	
	/** Az ingatlan valamennyi adat�t szolg�ltatja. */
	public String toString() {
		StringBuffer sb = new StringBuffer("Az ingatlan t�pusa: " + getClass() + 
			"\nAlapter�lete: " + alapterulet + "m2\n" +
			"Gar�zs t�pusa: " + garazs +
			"\nRezsik�lts�gek:\n");
		Set<String> kulcsHalmaz = rezsikoltsegek.keySet();
		for(String nev : kulcsHalmaz) {
			sb.append("\t" + nev + ": " + rezsikoltsegek.get(nev) + "\n");
		}
		return sb.toString();
	}
	
	/** �j rezsi felv�tele. Meg kell adni a rezsi megnevez�s�t �s �sszeg�t.
	@param nev A rezsi megnevez�se, pl. v�z, g�z vagy telefon.
	@param koltseg A rezsi �tlagos havi �sszege.
	@throws LetezoRezsiException */
	public void addRezsi(String nev, int koltseg) throws LetezoRezsiException {
		if(rezsikoltsegek.containsKey(nev)) {
			throw new LetezoRezsiException(nev);
		}
		rezsikoltsegek.put(nev, koltseg);
	}
	
	/** A havi �tlagos rezsik�lts�get szolg�ltatja, vagyis a rezsik �sszeg�t.
	@return A havi rezsik�lts�gek �sszeg�vel t�r vissza. */
	public int getAtlRezsi() {
		Set<String> kulcsHalmaz = rezsikoltsegek.keySet();
		int osszeg = 0;
		for(String nev : kulcsHalmaz) {
			osszeg += rezsikoltsegek.get(nev);
		}
		return osszeg;
	}
	
	
	/** A megadott objektumba �rja azokat az adatokat, amiket a toString visszaad.
	@param w Ebbe a folyamba fogjuk �rni az objektum adatait. */
	public void toFile(PrintWriter w) {
		w.println(toString());
	}
}