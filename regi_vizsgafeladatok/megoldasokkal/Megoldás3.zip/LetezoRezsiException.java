public class LetezoRezsiException extends Exception {
	public LetezoRezsiException(String msg) {
		super(msg);
	}
	
	public String toString() {
		return "Ilyen nevu rezsi (" + getMessage() + ") m�r l�tezik.";
	}
}